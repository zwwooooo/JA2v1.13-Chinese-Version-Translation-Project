=====================================
======>>>>>STI-Edit v. 1.3<<<<<======
=====================================

Dieses Archiv enth�lt STI-Edit, ein Programm zum editieren von Sirtechs *.sti-Bilddateien. Das Programm ist Freeware und darf beliebig weitergereicht und kopiert werden solange folgende Dateien mitgeliefert werden:

	STI-Edit.exe 	- die Programmdatei
	pals.bin 	- Standartpaletten
	readme.txt	- diese Textdatei
	STI-Edit.en	- das GUI in Englisch.

Wenn das Programm �ber eine Internetseite zum Download bereitgestellt werden soll ist vorher die Erlaubnis des Autors einzuholen (BimboMainia@gmx.net).

Der Autor �bernimmt keinerlei Haftung f�r Sch�den die durch dieses Programm oder durch die Nutzung dieses Programms entstehen.

Kontakt + Support:
Kurz nach dem Release wird eine Hilfedatei an der selben Stelle bereit gestellt werden von der das Programm bezogen werden konnte (siehe unten) bitte zuerst diese Datei genau lesen. Sollten Fragen dort nicht gekl�rt werden bitte ins Forum posten:
	www.jaggedalliance2.de/forum
Bei direkten Fragen zu STI-Edit die nicht im Forum zu kl�ren wahren kann man mich per E-Mail erreichen:
	BimboMainia@gmx.net

Updates (und die Hilfedatei):
	www.ub-maps.de
	www.jaggedalliance2.de

Viel Spa� mit dem Programm!
	Bimbo

========================in english:============================

This archive contains STI-Edit a program designed to change the .sti-graphics files form Sirtechs Jagged Alliance 2. This software is freeware and you are allowed to give it away and copy it as you want as long as you distribute this files with it:

	STI-Edit.exe	-the programs executable
	pals.bin	-some palettes
	readme.txt	-this file
	STI-Edit.en	-a localized GUI

If you want do make this archive downloadable on your website please contact author before (BimboMainia@gmx.net).

The author of this software takes no responsibilities for troubles this software may cause or that may caused by using this software.

Contact + Support:
Shortly after the release of this software a help file will be ready for download at the same page you downloaded this archive (or an location listed below). If this file cant answer your questions please post on the Lords of the Bytes forum, program discussion section:
	www.Lords-of-the-Bytes.com
If you have a question directly linked with STI-Edit that could not been answered there feel free to send me an e-mail:
	BimboMainia@gmx.net

Updates (and the help file):
	www.ja-galaxy.com

So now start moding and enjoy!
	Bimbo