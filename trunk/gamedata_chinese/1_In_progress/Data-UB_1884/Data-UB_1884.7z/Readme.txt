

加 *和 1.13 不同的文件：

【XML】

Data-UB\TableData\CivGroupNames.xml.xml
（Data\TableData\CivGroupNames.xml.xml）

Data-UB\TableData\Map\Cities.xml
（Data\TableData\Map\Cities.xml）

*Data-UB\TableData\Map\FacilityTypes.xml
（Data\TableData\Map\FacilityTypes.xml）

Data-UB\TableData\Map\ShippingDestinations.xml
（Data\TableData\Map\ShippingDestinations.xml）

========

Data-UB\AddOns\Data-UB-Vanilla\TableData\OldAIMArchive.xml
（Data\TableData\Chinese.OldAIMArchive.xml）

Data-UB\AddOns\Data-UB-Vanilla\TableData\Email\EmailMercAvailable.xml
（Data\TableData\Email\EmailMercAvailable.xml）

Data-UB\AddOns\Data-UB-Vanilla\TableData\Email\EmailMercLevelUp.xml
（Data\TableData\Email\EmailMercLevelUp.xml）

Data-UB\AddOns\Data-UB-Vanilla\TableData\Email\EmailSenderNameList.xml
（Data\TableData\Email\EmailSenderNameList.xml）

----
Data-UB\AddOns\Data-UB-1.13\TableData\OldAIMArchive.xml
（Data-1.13\TableData\Chinese.OldAIMArchive.xml）

Data-UB\AddOns\Data-UB-Vanilla\TableData\Email\EmailMercAvailable.xml
（Data-1.13\TableData\Email\EmailMercAvailable.xml）

Data-UB\AddOns\Data-UB-Vanilla\TableData\Email\EmailMercLevelUp.xml
（Data-1.13\TableData\Email\EmailMercLevelUp.xml）

Data-UB\AddOns\Data-UB-Vanilla\TableData\Email\EmailSenderNameList.xml
（Data-1.13\TableData\Email\EmailSenderNameList.xml）


【EDT】

*Data-UB\binarydata\AIMPOL25.EDT
*Data-UB\binarydata\EMAIL25.EDT
*Data-UB\binarydata\HELP.EDT
Data-UB\binarydata\IMPTXT25.EDT（Data\binarydata\IMPTEXT.EDT）
*Data-UB\binarydata\QUESTS25.EDT
*Data-UB\binarydata\RIS25.EDT

*Data-UB\MercEdt\051.EDT
*Data-UB\MercEdt\052.EDT
*Data-UB\MercEdt\053.EDT
*Data-UB\MercEdt\054.EDT
*Data-UB\MercEdt\055.EDT
*Data-UB\MercEdt\056.EDT
*Data-UB\MercEdt\057.EDT
*Data-UB\MercEdt\058.EDT
*Data-UB\MercEdt\059.EDT
*Data-UB\MercEdt\060.EDT
*Data-UB\MercEdt\061.EDT
*Data-UB\MercEdt\062.EDT
*Data-UB\MercEdt\064.EDT

*Data-UB\Npcdata\060.EDT
*Data-UB\Npcdata\061.EDT
*Data-UB\Npcdata\062.EDT
*Data-UB\Npcdata\06.EDT
*Data-UB\Npcdata\073.EDT
*Data-UB\Npcdata\074.EDT
*Data-UB\Npcdata\075.EDT
*Data-UB\Npcdata\076.EDT
*Data-UB\Npcdata\077.EDT
*Data-UB\Npcdata\159.EDT
*Data-UB\Npcdata\CIV40.EDT
*Data-UB\Npcdata\CIV42.EDT
*Data-UB\Npcdata\CIV43.EDT

----
*Data-UB\AddOns\Data-UB-Vanilla\binarydata\AIMBIOS.EDT
（Data\binarydata\AIMBIOS.EDT）

*Data-UB\AddOns\Data-UB-Vanilla\binarydata\MERCBIOS.EDT
（Data\binarydata\MERCBIOS.EDT）

*Data-UB\AddOns\Data-UB-1.13\binarydata\AIMBIOS.EDT
（Data-1.13\binarydata\AIMBIOS.EDT）

*Data-UB\AddOns\Data-UB-1.13\binarydata\MERCBIOS.EDT
（Data-1.13\binarydata\MERCBIOS.EDT）



